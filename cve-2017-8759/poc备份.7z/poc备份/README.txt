﻿1、将 cmd.hta 和 server.txt 文件放在 HTTP 服务端（10.10.1.4）的根目录
2、修改 ppsx、rtf、server.txt 文档中的 URL 为服务器的 IP 地址
2、客户端点击 CVE-2017-8759.rtf 或者 CVE-2017-8759.ppsx 即可触发漏洞