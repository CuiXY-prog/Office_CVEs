#分析流程
	#函数调用
	r $t0 = 0
	bp wwlib!PTLS7::FsDestroySubpageBreakRecord+0x10dc6 "r $t0=@$t0+1;.printf \"times: %d\n\",@$t0;.echo;.if(@$t0 == 0x5){}.else{gc}"

	#对象位置和数据结构
	dd poi(poi(poi(esp+8)+5fc))
	05676f18  000000c7 00000000 00000000 00000002
	05676f28  40ef8900 00000000 00000002 40ef8900
	05676f38  00000000 00000000 00000000 00000000
	05676f48  000100f0 00000000 00000000 00000000
	05676f58  00000000 00000000 00000000 00000000

	#tls分配调用断点, 在断下 wwlib 后第一个 tls 地址
	bp KERNEL32!TlsGetValueStub ".if(poi(esp+4) = 0x1e){kb L1; gc;}.else{gc}"
	bp KERNEL32!TlsSetValueStub ".if(poi(esp+4) = 0x1e){}.else{gc}"

	#对数据结构下断点，看何时写入tls
	ba w4 0571ef28

	#写入的指令地址
	wwlib!PTLS7::LsAssert+0x2ed8c

	#内存错误数据列表和断点
	bp wwlib!PTLS7::LsAssert+0x2dc5b ".echo; dd poi(poi(ecx + 5fc)); gc;"

	59a96f90  00000000 00000002 00000048 00000001
	59a96fa0  00000000 00000000 00000000 00000003
	59a96fb0  c0c0c0c0 c0c0c0c0 c0c0c0c0 c0c0c0c0
	59a96fc0  c0c0c0c0 c0c0c0c0 c0c0c0c0 c0c0c0c0
	59a96fd0  c0c0c0c0 c0c0c0c0 c0c0c0c0 c0c0c0c0
	59a96fe0  c0c0c0c0 c0c0c0c0 c0c0c0c0 c0c0c0c0
	59a96ff0  c0c0c0c0 c0c0c0c0 c0c0c0c0 d0d0d0d0

	...

	59a96f90  00000001 00000002 00000048 00000001
	59a96fa0  00000001 00000000 00000000 00000000
	59a96fb0  00000003 09c00c0c 00000000 000000b3
	59a96fc0  000005a0 000002cf 3c3b0274 403f3e3d
	59a96fd0  00000000 00000000 00000000 00000000
	59a96fe0  00000000 00000000 00000000 00000000
	59a96ff0  00000000 00000000 00000000 d0d0d0d0

	#对数据下断点看何时写入
	ba w4 00b35524          
	wwlib!PTLS7::FsUpdateFinitePage+0x39df6 函数完成了数据的复制

	#数据写入父函数为
	bp wwlib!PTLS7::FsUpdateFinitePage+0x39cfe

	#0x09c00c0c 数据由以下指令处理
	bp wwlib!PTLS7::FsUpdateFinitePage+0x74077

	#lpolestream->lpstbl源(0x8fc4)
	bp wwlib!PTLS7::FsUpdateFinitePage+0x758ff

	#处理rtf的函数，其中会调用以上函数进行处理
	bp wwlib!PTLS7::FsUpdateFinitePage+0x6d049
		bp wwlib!PTLS7::FsUpdateFinitePage+0x761e2
		
	#以下指令写入 0x09c00c0c
	bp wwlib!PTLS7::FsUpdateFinitePage+0x7a9c7 ".echo; r bl; dd ecx+eax+8FA0h L4; gc;"



#漏洞原因

	wwlib!PTLS7::FsUpdateFinitePage+0x6d181(66a16efc) - 调用 sub_66A16C81 对控制字后面的数字经过运算后得出一个值并返回，将此值标识为 "控制字后数字运算值"
	wwlib!PTLS7::FsUpdateFinitePage+0x6d29c(66a17017) - 写入 "控制字后数字运算值" 到 lpolestream->lpstbl + 0x8FA0 开始的地址
		wwlib!PTLS7::FsUpdateFinitePage+0x7a9c0(66A2473B)

		#初始数据
	56bc1450  00000009 00000000 00000000 00000000
	56bc1460  00000000 00000000 00000000 00000000
	56bc1470  00000001 56f30f90 00000000 00000000
	56bc1480  00000000 00000000 00000000 00000000
	56bc1490  00000000 00000000 00000000 00000000
	56bc14a0  00000000 00000000 00000000 00000000
	56bc14b0  00000000 00000000 00000000 00000000
	56bc14c0  56f30f90 00000000 00000000 00000001

		#覆盖了原有的对象
	56bc1450  0c0cc009 0c09c00c 0c09c00c 0c09c00d
	56bc1460  0bc0090c 15172018 09c00c0c 200c09c0
	56bc1470  00000028 09c00c0c 00000000 00000000
	56bc1480  00000000 00000000 00000000 00000000
	56bc1490  00000000 00000000 00000000 00000000
	56bc14a0  00000000 00000000 00000000 00000000
	56bc14b0  00000000 00000000 00000000 00000000
	56bc14c0  56f30f90 00000000 00000000 00000001

	wwlib!PTLS7::FsUpdateFinitePage+0x74113(66a1de8e) - 传入 lpolestream->lpstbl + 0x8FC4 地址(包含 "控制字后数字运算值")并进行处理
	wwlib!PTLS7::FsUpdateFinitePage+0x39dc7(669e3b42) - 获取 "控制字后数字运算值" 四个字节的数据, 也就是从 lpolestream->lpstbl + 0x8FA0 地址开始
	wwlib!PTLS7::FsUpdateFinitePage+0x39dc0(669E3B3B) - 将 "控制字后数字运算值" 四个字节的数据以及其他数据写入 TLS 中
	wwlib!PTLS7::FsDestroySubpageBreakRecord+0x10920(669477DD) - 取出 TLS 结构
	wwlib!PTLS7::FsDestroySubpageBreakRecord+0xbfdd(66942E9A) - 取出 "控制字后数字运算值" 结构中的 09c00c0c 数据, 参数来源于 poi(poi(poi(第三个参数+0x5fc))) + 0x24

	506e2f90  00000001 00000002 00000048 00000001
	506e2fa0  00000001 00000000 00000000 00000000
	506e2fb0  00000003 09c00c0c 00000000 000000b3
	506e2fc0  000005a0 000002cf 3c3b0274 403f3e3d
	506e2fd0  00000000 00000000 00000000 00000000
	506e2fe0  00000000 00000000 00000000 00000000
	506e2ff0  00000000 00000000 00000000 d0d0d0d0

	wwlib!PTLS7::FsDestroySubpageBreakRecord+0xbff8(66942EB5) - call [poi(0x09c00c0c) + 1ch]


#崩溃时堆栈
	r $t0 = 0

	bp wwlib!PTLS7::FsDestroySubpageBreakRecord+0x10dc6 "r $t0=@$t0+1;.printf \"times: %d\n\",@$t0;.echo;.if(@$t0 == 0x5){}.else{gc}"
		bp wwlib!PTLS7::LsAssert+0x2dc5b ".echo; dd poi(poi(ecx + 5fc)); kb L3;"





