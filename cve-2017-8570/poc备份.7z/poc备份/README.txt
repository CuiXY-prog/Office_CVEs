RTF 文件: 双击后处罚
PPSX 文件: 将 server.sct 放到服务器根目录在, 并通过压缩软件修改 ppt\slides\_rels\slide1.xml.rels 中的路径, 之后双击触发