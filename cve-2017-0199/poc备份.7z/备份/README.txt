1. 新建 server.rtf 存放在 HTTP 服务器可访问路径
2. 新建 test.rtf 并创建 server.rtf 的链接对象（插入->对象->由文件创建，并选中链接）
3. 替换 server.rtf 为包含 HTA 脚本的新 server.rtf 文件
4. 将服务器 \conf\mime.types 配置文件中关于 rtf 文件类型的一行修改为 "application/rtf    rtf"，并重启 apache
5. 打开 test.rtf 文档并双击其中包含的链接文档后运行 HTA 脚本