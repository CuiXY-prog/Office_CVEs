## What?

This repo contains a Proof of Concept exploit for CVE-2017-8570, a.k.a the "Composite Moniker" vulnerability. This demonstrates using the Packager.dll trick to drop an sct file into the %TEMP% directory, and then execute it using the primitive that the vulnerability provides.

## Why?

A few reasons.

1. I wanted to see if it was possible to use the [Packager.dll file-dropping trick](https://securingtomorrow.mcafee.com/mcafee-labs/dropping-files-temp-folder-raises-security-concerns/) to exploit this vulnerability.
2. As far as I'm aware, all other public exploits for CVE-2017-8570 are actually exploiting the "Script Moniker" variant of CVE-2017-0199 and are not actually composite moniker exploits.
3. Raise awareness of exploitation techniques used in the wild, and help defenders to detect exploitation attempts.

## How to run

Simply run the script, providing an Sct file to execute, and an output name for your RTF file:

    python packager_composite_moniker.py -s calc.sct -o example.rtf
    [+] RTF file written to: example.rtf


## Detection

I have included a Yara rule to detect attempts to exploit this vulnerability via RTF.

## References

- https://justhaifei1.blogspot.co.uk/2017/07/bypassing-microsofts-cve-2017-0199-patch.html
- https://securingtomorrow.mcafee.com/mcafee-labs/dropping-files-temp-folder-raises-security-concerns/
- https://portal.msrc.microsoft.com/en-US/security-guidance/advisory/CVE-2017-8570