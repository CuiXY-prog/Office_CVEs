1、将 server.rtf 放到 IP 地址为 192.168.1.21 的 Windows Apache 服务器上
2、将 Apache 的 conf\mime.types 文件中的 application/rtf rtf 修改为 application/hta rtf
3、最后双击 exploit.rtf 就会弹出计算器