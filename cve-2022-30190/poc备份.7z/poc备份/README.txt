﻿1、本地搭建 web 服务器，之后将 exploit.html 放到 web 根目录
2、双击 cve-2022-30190.docx