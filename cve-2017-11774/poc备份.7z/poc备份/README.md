# SniperRoost
used to generate a valid attack chain to exploit CVE-2017-11774 tied to iranian apt only reasearch poc dont use for harm please
